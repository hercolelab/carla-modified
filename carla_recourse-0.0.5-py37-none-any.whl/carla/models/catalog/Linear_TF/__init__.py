# flake8: noqa

from .model_linear import LinearModel
