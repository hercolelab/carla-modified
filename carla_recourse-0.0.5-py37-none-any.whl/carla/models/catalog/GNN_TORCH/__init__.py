# flake8: noqa

from .model_gnn import TreeGridModel
