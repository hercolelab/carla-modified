# flake8: noqa

from .data import Data
